# stroke-prediction
machine learning project for predicting stroke

Please open **Stroke Prediction.ipynb** for more detailed explanation.

[Click Here To View File](https://github.com/AniruddhaMane940/stroke-prediction/blob/main/Stoke%20Prediction.ipynb)
